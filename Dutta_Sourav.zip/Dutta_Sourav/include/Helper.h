#include <string>
#include <vector>

using namespace std;

int stringToInt(string s);
double stringToDouble(string s);
void toPrecisionOneForInt(ofstream& file, double d);
int searchArray(vector < double > array, double d);
int compareValues(double d1, double d2);
